# Source Data 3 Disease N robustness

The primary disease sample size of 24,510 matches the source GJOKA SuSiE-RSS analysis. This archive records a frozen secondary stress test using case-control Neff=21,584.38. It does not replace the primary model. The 33-comparison workload was selected before the rerun.
