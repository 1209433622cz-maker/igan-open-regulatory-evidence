# Source Data 1 for npj Genomic Medicine

Complete primary aggregate evidence in S1/ through S10/. The separate editable workbook contains ten worksheet views; it is not a substitute for the complete large tables.

Scientific data members retain the frozen source-release bytes. Historical filenames and source-state files document provenance rather than additional analyses. See the submitted Supplementary Information for units and interpretation limits.

No source BAMs, donor genotypes or source pseudobulk matrices are redistributed. Shared genetic signals do not establish mediation or clinical utility.
