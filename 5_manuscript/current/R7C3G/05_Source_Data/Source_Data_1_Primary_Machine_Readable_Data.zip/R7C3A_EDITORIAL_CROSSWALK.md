# Data-filename crosswalk

- Historical `R7B3A_Supplementary_Tables_S1-S10.xlsx` in the frozen manifest = current separately uploaded `Supplementary_Data_1_Tables_S1-S10.xlsx` (identical SHA-256).
- Historical `Human Genomics` mention in old README was journal metadata drift, not a different study.
- All scientific S1–S10 members retain their source hashes.
