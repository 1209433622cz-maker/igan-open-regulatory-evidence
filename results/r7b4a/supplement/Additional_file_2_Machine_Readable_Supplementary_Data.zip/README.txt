R7B4A machine-readable supplementary data

This bundle accompanies the Human Genomics submission-interface manuscript.
It contains public source/derived tables from Supplementary Tables S1-S10.
The editable XLSX workbook is supplied separately as Additional file 1.
Individual-level genotype, BAM, pseudobulk matrices and licensed source archives
are not included. See S1 and SUPPLEMENT_FINAL_MANIFEST.tsv for provenance.
