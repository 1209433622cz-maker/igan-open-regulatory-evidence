# Reader note

Historical `Additional file 3` in the old README was a generic upload label. The current npj file is named `Source_Data_2_R7C3A_Editorial_Crosswalk.zip`; the actual R7C0 source tables and external-validation result identities are unchanged.
