# Source Data 2 for npj Genomic Medicine

Bounded external disease-study, CASCADE, chromatin and descriptive OMIX evidence (S11 family) in data/.

Scientific data members retain the frozen source-release bytes. Historical filenames and source-state files document provenance rather than additional analyses. See the submitted Supplementary Information for units and interpretation limits.

No source BAMs, donor genotypes or source pseudobulk matrices are redistributed. Shared genetic signals do not establish mediation or clinical utility.
